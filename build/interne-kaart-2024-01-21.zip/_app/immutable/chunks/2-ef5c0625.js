import{default as t}from"../components/pages/_page.svelte-77d523f1.js";export{t as component};
