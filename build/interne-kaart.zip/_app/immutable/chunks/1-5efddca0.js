import{default as t}from"../components/error.svelte-c1c5e894.js";export{t as component};
