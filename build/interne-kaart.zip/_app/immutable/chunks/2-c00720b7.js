import{default as t}from"../components/pages/_page.svelte-16a418d3.js";export{t as component};
